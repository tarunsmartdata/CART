import authReducer from './auth';
import dashReducer from './dash';

export {authReducer, dashReducer};
